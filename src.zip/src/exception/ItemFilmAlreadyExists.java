package exception;

public class ItemFilmAlreadyExists extends Exception {

	public ItemFilmAlreadyExists(String message) {
		super(message);
	}
	
}
