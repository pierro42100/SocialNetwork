package exception;

public class ItemBookAlreadyExists extends Exception {

	public ItemBookAlreadyExists(String message) {
		super(message);
	}
}
