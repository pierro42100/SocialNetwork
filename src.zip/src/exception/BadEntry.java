package exception;

public class BadEntry extends Exception {

	public BadEntry(String message) {
		super(message);
	}
}
