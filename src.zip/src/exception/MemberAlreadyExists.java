package exception;

public class MemberAlreadyExists extends Exception {

	public MemberAlreadyExists(String message) {
		super(message);
	}
	
}
